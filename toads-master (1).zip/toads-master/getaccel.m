function [a] = getaccel(fnet, m)

%% CALCULATIONS
a = fnet / m; %calculate acceleration based off of fnet and mass (m/s^2)

end