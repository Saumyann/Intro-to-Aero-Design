function heightnew = gethigh(height, velocity, dt)

%% CALCULATIONS
heightnew = height + dt * velocity; %Update height

end