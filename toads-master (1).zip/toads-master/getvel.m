function vnew = getvel(velocity, acceleration, dt)

%% CALCULATIONS
vnew = velocity + dt * acceleration; %Update velocity

end